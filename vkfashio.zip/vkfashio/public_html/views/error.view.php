<body class="uk-height-1-1">

<div class="uk-vertical-align uk-text-center uk-height-1-1 errorpage">
	<div class="uk-vertical-align-middle">


		<img src="<?php echo $urlPath->assets_img('icon.png'); ?>" class="icon"/>
		<h2><?php echo _ERRORTITLE ?></h2>
		<a href="<?php echo $urlPath->home(); ?>" class="uk-button"><?php echo _ERRORBUTTON ?></a>


	</div>
</div>






