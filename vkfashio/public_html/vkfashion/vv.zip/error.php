<?php

require "core.php";

// Title

$titleHeader = getTitle($connect);


require './header.php';
require './views/error.view.php';
require './footer.php';

?>