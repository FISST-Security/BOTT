<?php

require './views/blank.view.php';

?>