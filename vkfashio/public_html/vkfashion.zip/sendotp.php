<?php
$mobile = $_POST['mobile'];

//echo '<pre>'; print_r($_POST); die;


function smsApi(){
    $otp = rand(1000, 9999);
    if(checkUniqueOTP($otp)) {
        $base_url = "http://alerts.icisms.in/api/v4/?api_key=lz87kv9o80xxxxxxxxxxxxxxxxxxxxxxxxx";
        $message = urlencode("Your OTP is: ".$otp);
        $full_url = $base_url."&method=sms&message=".$message."&to=".$mobile."&sender=LATICE";
        echo $full_url; die;
        $curl_handle=curl_init();
        curl_setopt($curl_handle,CURLOPT_URL,$full_url);
        curl_setopt($curl_handle,CURLOPT_CONNECTTIMEOUT,2);
        curl_setopt($curl_handle,CURLOPT_RETURNTRANSFER,1);
        $buffer = curl_exec($curl_handle);
        
        if (!curl_errno($curl_handle)) {
            $info = curl_getinfo($curl_handle);
            echo '<pre>'; print_r($info); die;
        }
        curl_close($curl_handle);
        
        /*if (empty($buffer))
            print "Nothing returned from url.<p>";
        else
          print $buffer;*/
    }
}


function checkUniqueOTP($otp){
    $link = mysqli_connect("localhost", "bcstour_ott", "7792803988deepak", "bcstour_ott");
    // Check connection
    if($link === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }
    $sql = "SELECT * FROM users where otp =".$otp;
    $result = mysqli_num_rows($link->query($sql));
    if($result)
        checkUniqueOTP(rand(1000, 9999));
    else
        return true;
}

smsApi();

?>