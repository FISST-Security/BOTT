

<script src="<?php echo $urlPath->assets_js('jquery.js'); ?>"></script>
<script src="<?php echo $urlPath->assets_js('jquery.validate.js'); ?>"></script>
<script src="<?php echo $urlPath->assets_js('uikit.min.js'); ?>"></script>
<script src="<?php echo $urlPath->assets_js('/components/grid.min.js'); ?>"></script>
<script src="<?php echo $urlPath->assets_js('/components/slider.min.js'); ?>"></script>
<script src="<?php echo $urlPath->assets_js('plyr.js'); ?>"></script>
<script src="<?php echo $urlPath->assets_js('scrollbar.js'); ?>"></script>
<script src="<?php echo $urlPath->assets_js('main.js'); ?>"></script>

</body>
</html>