<?php

require './views/reviews.view.php';

?>