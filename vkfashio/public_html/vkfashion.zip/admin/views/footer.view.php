<script type="text/javascript" src="../assets/js/popper.min.js"></script>
<script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
<script src="../assets/js/bootstrap-select.js"></script>

<script type="text/javascript" src="../assets/js/modernizr.custom.js"></script>

<script type="text/javascript" src="../assets/plugins/customScroll/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="../assets/plugins/sortable2/sortable.min.js"></script>
<script type="text/javascript" src="../assets/plugins/date-range/moment.min.js"></script>
<script type="text/javascript" src="../assets/plugins/date-range/daterangepicker.js"></script>
<script type="text/javascript" src="../assets/plugins/data-tables/datatables.min.js"></script>
<script type="text/javascript" src="../assets/plugins/editable/editable.js"></script>
<script type="text/javascript" src="../assets/js/bootstrap-tagsinput.js"></script>
<script type="text/javascript" src="../assets/js/chosen.jquery.js"></script>

<script src="../assets/js/main.js"></script>
<script src="../assets/js/custom.js"></script>
</body>
</html>