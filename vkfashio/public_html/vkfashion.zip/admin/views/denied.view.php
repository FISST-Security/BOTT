
<div style="display: block; text-align: center; padding-top: 40px;">
    <h4>Access Denied</h4>
    <p>You don't have permission to view this page</p> 
</div>